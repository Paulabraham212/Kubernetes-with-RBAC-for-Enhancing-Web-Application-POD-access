from django.apps import AppConfig


class CrudserviceConfig(AppConfig):
    name = 'crudservice'
