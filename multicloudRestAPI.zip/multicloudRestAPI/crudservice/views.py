from rest_framework import viewsets
from .models import Article
from .serializers import ArticleSerializer
from django.http import HttpResponse
from django.shortcuts import render

class ArticleViewSet(viewsets.ModelViewSet):
    queryset = Article.objects.all()
    serializer_class = ArticleSerializer




def home(request):
    return render(request, 'crudservice/home.html')
